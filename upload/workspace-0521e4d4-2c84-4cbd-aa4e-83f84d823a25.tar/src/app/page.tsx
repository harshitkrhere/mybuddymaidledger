'use client';

import { useState } from 'react';
import { Masthead, IndexNav, Folio, AccountingTabs, type PageId } from '@/components/erp/ledger-ui';
import { Dashboard } from '@/components/erp/dashboard';
import { PlanSales } from '@/components/erp/plan-sales';
import { Customers } from '@/components/erp/customers';
import { Helpers } from '@/components/erp/helpers';
import { Placements } from '@/components/erp/placements';
import { Expenses } from '@/components/erp/expenses';
import { ChartOfAccounts } from '@/components/erp/chart-of-accounts';
import { Journal } from '@/components/erp/journal';
import { Reports } from '@/components/erp/reports';
import { Settings } from '@/components/erp/settings';

const PAGE_TITLES: Record<PageId, { title: string; subtitle: string }> = {
  dashboard: {
    title: 'Dashboard',
    subtitle: 'The books at a glance — revenue, ledger and field operations',
  },
  'plan-sales': {
    title: 'Plan Sales',
    subtitle: 'Silver · Gold · Diamond platform fees — GST and revenue post automatically',
  },
  customers: {
    title: 'Customers',
    subtitle: 'Households with plan coverage and placement usage',
  },
  helpers: {
    title: 'Helpers',
    subtitle: 'Verified domestic helpers — Aadhaar, police & reference checks',
  },
  placements: {
    title: 'Placements',
    subtitle: 'Connect families with helpers — replacements covered under plans',
  },
  expenses: {
    title: 'Payments',
    subtitle: 'Money out — bills, payouts & operating costs post to the ledger automatically',
  },
  accounts: {
    title: 'Accounting',
    subtitle: 'The chart of accounts — assets, liabilities, equity, revenue and expenses',
  },
  journal: {
    title: 'Accounting',
    subtitle: 'The double-entry ledger — every transaction, debits equal credits',
  },
  reports: {
    title: 'Reports',
    subtitle: 'Profit & Loss, Balance Sheet and Trial Balance',
  },
  settings: {
    title: 'Settings',
    subtitle: 'Company profile, GST defaults and data backup',
  },
};

export default function Home() {
  const [page, setPage] = useState<PageId>('dashboard');

  const navigate = (p: string) => {
    setPage(p as PageId);
    if (typeof window !== 'undefined') window.scrollTo({ top: 0 });
  };

  const meta = PAGE_TITLES[page];

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Masthead />
      <IndexNav page={page} onNavigate={navigate} />

      <main className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-5 sm:px-6 sm:py-6 lg:px-10">
        {/* Page heading — broadsheet style */}
        <div className="mb-5 sm:mb-6">
          <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-2">
            <div>
              <h1 className="font-serif text-2xl font-semibold tracking-tight text-primary sm:text-[27px]">
                {meta.title}
              </h1>
              <p className="mt-1 font-serif text-[13px] italic text-muted-foreground">{meta.subtitle}</p>
            </div>
            {(page === 'accounts' || page === 'journal') && (
              <AccountingTabs active={page === 'journal' ? 'journal' : 'accounts'} onNavigate={navigate} />
            )}
          </div>
        </div>

        {page === 'dashboard' && <Dashboard onNavigate={navigate} />}
        {page === 'plan-sales' && <PlanSales />}
        {page === 'customers' && <Customers />}
        {page === 'helpers' && <Helpers />}
        {page === 'placements' && <Placements />}
        {page === 'expenses' && <Expenses />}
        {page === 'accounts' && <ChartOfAccounts />}
        {page === 'journal' && <Journal />}
        {page === 'reports' && <Reports />}
        {page === 'settings' && <Settings />}
      </main>

      <Folio page={page} warning="GSTR-3B DUE 20 NOV" />
    </div>
  );
}
