'use client';

import { useEffect, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { PLANS, PLAN_KEYS } from '@/lib/constants';
import { fmtMoney, SecHead, DottedStat, SourceBadge, ErrorNote } from './shared';
import { LedgerChart } from './ledger-ui';

interface DashboardData {
  period: { key: string; label: string };
  kpis: {
    cash: number;
    totalRevenue: number;
    totalExpenses: number;
    netIncome: number;
    totalAssets: number;
    totalLiabilities: number;
    totalEquity: number;
    gstPayable: number;
    activePlans: number;
    activePlacements: number;
    availableHelpers: number;
    customerCount: number;
    salesInPeriod: number;
    monthRevenue: number;
  };
  months: { key: string; label: string; revenue: number; expenses: number }[];
  planMix: { plan: string; count: number }[];
  cityMix: { city: string; count: number }[];
  cityOps: { city: string; customers: number; helpers: number; placements: number; revenue: number }[];
  expenseByCategory: { category: string; total: number }[];
  recentTransactions: {
    id: string;
    entryNumber: string;
    date: string;
    memo: string;
    source: string;
    amount: number;
    cashDelta: number;
    balance: number;
  }[];
}

const PERIODS: { key: 'month' | 'fy' | 'all'; label: string }[] = [
  { key: 'month', label: 'THIS MONTH' },
  { key: 'fy', label: 'THIS FY' },
  { key: 'all', label: 'ALL TIME' },
];

const PLAN_SWATCH: Record<string, string> = {
  SILVER: '#a9c4b0',
  GOLD: '#476b57',
  DIAMOND: '#c08a2e',
};

export function Dashboard({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState('');
  const [period, setPeriod] = useState<'month' | 'fy' | 'all'>('all');

  const load = async (p: 'month' | 'fy' | 'all') => {
    try {
      setError('');
      const res = await fetch(`/api/dashboard?period=${p}`);
      if (!res.ok) throw new Error('Failed to load dashboard');
      setData(await res.json());
    } catch {
      setError('Could not load the books. Please refresh.');
    }
  };

  useEffect(() => {
    load(period);
  }, [period]);

  if (error) return <ErrorNote message={error} />;

  if (!data) {
    return (
      <div className="space-y-6">
        <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
          <div className="space-y-3">
            <Skeleton className="h-3 w-40" />
            <Skeleton className="h-20 w-64" />
            <Skeleton className="h-4 w-72" />
          </div>
          <div className="space-y-5 pt-1">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-3 w-32" />
                <Skeleton className="h-6 w-full" />
              </div>
            ))}
          </div>
        </div>
        <Skeleton className="h-56 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const { kpis, months, planMix, cityOps, expenseByCategory, recentTransactions } = data;
  const periodLabel = data.period?.label ?? 'All time';

  // hero note — month-on-month compounding from the live series
  const last = months[months.length - 1];
  const prev = months[months.length - 2];
  let momNote = '';
  if (last && prev && prev.revenue > 0 && last.revenue > prev.revenue) {
    const pct = Math.round(((last.revenue - prev.revenue) / prev.revenue) * 100);
    momNote = `Compounding ${pct}% month-on-month — best month yet, ${fmtMoney(last.revenue, { compact: true })} booked in ${last.label}.`;
  } else if (last) {
    momNote = `Latest month booked ${fmtMoney(last.revenue, { compact: true })} across plans and services.`;
  }

  // plan portfolio values
  const totalActivePlans = planMix.reduce((s, p) => s + p.count, 0);
  const bookedValue = planMix.reduce((s, p) => s + p.count * (PLANS[p.plan]?.fee ?? 0), 0);
  const coverMonths = planMix.reduce((s, p) => s + p.count * (PLANS[p.plan]?.coverMonths ?? 12), 0);
  const monthlyEquiv = coverMonths > 0 ? bookedValue / coverMonths : 0;
  const maxCityRevenue = Math.max(...cityOps.map((c) => c.revenue), 1);
  const maxExpense = Math.max(...expenseByCategory.map((c) => c.total), 1);

  const ledgerLink = (
    <button
      onClick={() => onNavigate?.('journal')}
      className="text-[10px] font-bold tracking-[0.15em] text-primary underline-offset-4 hover:underline"
    >
      OPEN FULL LEDGER →
    </button>
  );

  return (
    <div className="space-y-8">
      {/* ============ figures ============ */}
      <section aria-label="Key figures">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-5" role="group" aria-label="Dashboard period">
            {PERIODS.map((p) => (
              <button
                key={p.key}
                onClick={() => setPeriod(p.key)}
                aria-pressed={period === p.key}
                className={cn(
                  'border-b-2 pb-1 text-[10px] font-bold tracking-[0.15em] transition-colors',
                  period === p.key
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-primary'
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
          <p className="text-[10px] font-medium uppercase tracking-[0.15em] text-muted-foreground">
            Showing · {periodLabel}
          </p>
        </div>

        <div className="grid gap-x-10 gap-y-7 lg:grid-cols-[minmax(300px,420px)_1fr]">
          {/* hero figure */}
          <div>
            <p className="caps-label flex items-center gap-2 text-primary">
              <span className="inline-block h-[7px] w-[7px] bg-primary" aria-hidden="true" />
              GROSS REVENUE
              <span className="font-medium tracking-[0.16em] text-muted-foreground/80">{periodLabel.toUpperCase()}</span>
            </p>
            <p className="mt-3 font-serif font-semibold leading-[0.9] tracking-tight text-primary">
              <span
                className={cn(
                  'align-baseline font-medium',
                  fmtMoney(kpis.totalRevenue, { compact: true }).length > 6 ? 'text-[36px]' : 'text-[32px] sm:text-[40px]'
                )}
              >
                ₹
              </span>
              <span
                className={
                  fmtMoney(kpis.totalRevenue, { compact: true }).length > 6 ? 'text-[44px]' : 'text-[64px] sm:text-[80px]'
                }
              >
                {fmtMoney(kpis.totalRevenue, { compact: true }).slice(1)}
              </span>
            </p>
            <p className="mt-4 max-w-[400px] font-serif text-[13.5px] italic leading-relaxed text-muted-foreground">
              {momNote}{' '}
              <span className="not-italic">
                {kpis.salesInPeriod} plan sales across {kpis.customerCount} households.
              </span>
            </p>
          </div>

          {/* dotted-leader stats */}
          <div className="flex flex-col justify-between gap-7 border-l border-[#1f3a2b]/15 pl-10 lg:border-l">
            <DottedStat
              label="CASH & BANK"
              value={fmtMoney(kpis.cash, { compact: true })}
              sub={`ASSETS ${fmtMoney(kpis.totalAssets, { compact: true })} · EQUITY ${fmtMoney(kpis.totalEquity, { compact: true })}`}
            />
            <DottedStat
              label="NET INCOME"
              value={fmtMoney(kpis.netIncome, { sign: true, compact: true })}
              tone={kpis.netIncome >= 0 ? 'positive' : 'negative'}
              sub={`EXPENSES ${fmtMoney(kpis.totalExpenses, { compact: true })} IN ${periodLabel.toUpperCase()}`}
            />
            <DottedStat
              label="GST PAYABLE"
              value={fmtMoney(kpis.gstPayable, { compact: true })}
              tone="warning"
              sub="GSTR-3B DUE 20 NOV · OUTPUT @18%"
            />
          </div>
        </div>
      </section>

      {/* ============ revenue v expenses ============ */}
      <section aria-label="Revenue versus expenses">
        <SecHead
          title="REVENUE"
          italic="v"
          meta="LAST SIX MONTHS · FIGURES IN ₹ THOUSANDS"
          action={
            <span className="flex flex-wrap items-center gap-4">
              <span className="flex items-center gap-2 text-[10px] font-semibold tracking-[0.14em] text-muted-foreground">
                <i className="inline-block w-4 border-t-2 border-solid border-primary" aria-hidden="true" />
                REVENUE
              </span>
              <span className="flex items-center gap-2 text-[10px] font-semibold tracking-[0.14em] text-muted-foreground">
                <i className="inline-block w-4 border-t-2 border-dashed border-[#b4822a]" aria-hidden="true" />
                EXPENSES
              </span>
              <span className="border border-[#1f3a2b]/20 px-2 py-1 text-[10px] font-semibold tracking-[0.12em] text-muted-foreground">
                CUMULATIVE NET{' '}
                <b className="font-mono text-[11px] font-semibold text-[#8f6511]">
                  {fmtMoney(kpis.netIncome, { compact: true })}
                </b>
              </span>
            </span>
          }
        />
        <LedgerChart months={months} className="mt-2" />
      </section>

      {/* ============ ledger + margin column ============ */}
      <div className="grid gap-x-10 gap-y-8 lg:grid-cols-[minmax(0,1.9fr)_minmax(260px,1fr)]">
        {/* recent ledger */}
        <section aria-label="Recent ledger">
          <SecHead title="RECENT LEDGER" meta={`${recentTransactions.length} LATEST POSTED ENTRIES`} action={ledgerLink} />
          <div className="thin-scroll -mx-1 overflow-x-auto px-1">
            <table className="mt-2 w-full min-w-[560px] border-collapse text-left">
              <thead>
                <tr className="rule-double-b">
                  <th scope="col" className="caps-label px-1 pb-2 pr-3 font-bold text-muted-foreground">DATE</th>
                  <th scope="col" className="caps-label px-1 pb-2 pr-3 font-bold text-muted-foreground">REF</th>
                  <th scope="col" className="caps-label px-1 pb-2 font-bold text-muted-foreground">PARTICULARS</th>
                  <th scope="col" className="caps-label px-1 pb-2 text-right font-bold text-muted-foreground">CASH IN ₹</th>
                  <th scope="col" className="caps-label px-1 pb-2 text-right font-bold text-muted-foreground">CASH OUT ₹</th>
                  <th scope="col" className="caps-label px-1 pb-2 text-right font-bold text-muted-foreground">BALANCE ₹</th>
                </tr>
              </thead>
              <tbody>
                {recentTransactions.map((t) => (
                  <tr key={t.id} className="border-b border-[#1f3a2b]/10 align-baseline hover:bg-[#1f3a2b]/[0.04]">
                    <td className="whitespace-nowrap px-1 py-2 pr-3 font-mono text-[10.5px] text-muted-foreground">
                      {`${String(new Date(t.date).getDate()).padStart(2, '0')} ${new Date(t.date)
                        .toLocaleDateString('en-IN', { month: 'short' })
                        .toUpperCase()}`}
                    </td>
                    <td className="whitespace-nowrap px-1 py-2 pr-3 font-mono text-[11px] font-medium text-primary">
                      {t.entryNumber}
                    </td>
                    <td className="max-w-[260px] truncate px-1 py-2 text-[13px] text-foreground">
                      {t.memo}
                      <span className="ml-2 align-baseline">
                        <SourceBadge source={t.source} />
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-1 py-2 text-right font-mono text-[12px] text-foreground">
                      {t.cashDelta > 0 ? t.cashDelta.toLocaleString('en-IN') : <span className="text-muted-foreground/60">—</span>}
                    </td>
                    <td className="whitespace-nowrap px-1 py-2 text-right font-mono text-[12px] text-[#8f6511]">
                      {t.cashDelta < 0 ? Math.abs(t.cashDelta).toLocaleString('en-IN') : <span className="text-muted-foreground/60">—</span>}
                    </td>
                    <td className="whitespace-nowrap px-1 py-2 text-right font-mono text-[12px] font-semibold text-primary">
                      {t.balance.toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="rule-double">
                  <td colSpan={5} className="caps-label px-1 pt-2.5 font-bold text-primary">
                    CLOSING BALANCE — CASH &amp; BANK
                  </td>
                  <td className="px-1 pt-2.5 text-right font-mono text-[13px] font-semibold text-primary">
                    {kpis.cash.toLocaleString('en-IN')}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>

        {/* margin column */}
        <div className="space-y-8">
          {/* plan portfolio */}
          <section aria-label="Plan portfolio">
            <SecHead title="PLAN PORTFOLIO" meta={`${totalActivePlans} ACTIVE`} />
            <div className="mt-3.5 flex items-end gap-4">
              <p className="font-serif text-[52px] font-semibold leading-[0.85] text-primary">{totalActivePlans}</p>
              <div className="pb-1">
                <p className="caps-label text-muted-foreground">ACTIVE SUBSCRIPTIONS</p>
                <p className="mt-1 font-serif text-[12.5px] italic text-muted-foreground">
                  {fmtMoney(bookedValue, { compact: true })} booked · {fmtMoney(monthlyEquiv, { compact: true })}/mo equivalent
                </p>
              </div>
            </div>
            <div className="mt-4 flex h-[14px]" aria-hidden="true">
              {PLAN_KEYS.map((k) => {
                const count = planMix.find((p) => p.plan === k)?.count ?? 0;
                return (
                  <i
                    key={k}
                    className="h-full border-r-[3px] border-r-background last:border-r-0"
                    style={{ width: `${totalActivePlans ? (count / totalActivePlans) * 100 : 0}%`, background: PLAN_SWATCH[k] }}
                  />
                );
              })}
            </div>
            <ul className="mt-3 space-y-2.5">
              {PLAN_KEYS.map((k) => {
                const count = planMix.find((p) => p.plan === k)?.count ?? 0;
                const pct = totalActivePlans ? Math.round((count / totalActivePlans) * 100) : 0;
                return (
                  <li key={k} className="flex items-end">
                    <span className="mb-0.5 inline-block h-2 w-2 shrink-0" style={{ background: PLAN_SWATCH[k] }} aria-hidden="true" />
                    <span className="caps-label mb-0.5 ml-2.5 text-foreground">
                      {k} · ₹{(PLANS[k].fee / 1000).toFixed(3)}K
                    </span>
                    <span className="leader" aria-hidden="true" />
                    <span className="font-mono text-[12px] font-semibold text-primary">
                      {count} · {pct}%
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>

          {/* operations abstract */}
          <section aria-label="Operations abstract">
            <SecHead title="OPERATIONS" meta="AT A GLANCE" />
            <div className="mt-1 grid grid-cols-2">
              {[
                { n: kpis.salesInPeriod, l: 'PLAN SALES', s: `in ${periodLabel.toLowerCase()}` },
                { n: kpis.customerCount, l: 'CUSTOMERS', s: 'households on the books' },
                { n: kpis.availableHelpers, l: 'VERIFIED HELPERS', s: 'checks complete' },
                { n: kpis.activePlacements, l: 'ACTIVE PLACEMENTS', s: 'helpers in homes' },
              ].map((cell) => (
                <div key={cell.l} className="rule-top-hair border-l border-[#1f3a2b]/10 px-4 py-3.5 odd:border-l-0">
                  <p className="font-serif text-[36px] font-semibold leading-none text-primary">{cell.n}</p>
                  <p className="caps-label mt-2 text-muted-foreground">{cell.l}</p>
                  <p className="mt-1 font-serif text-[11.5px] italic text-muted-foreground">{cell.s}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      {/* ============ city operations + expense abstract ============ */}
      <div className="grid gap-x-10 gap-y-8 lg:grid-cols-[minmax(0,1.9fr)_minmax(260px,1fr)]">
        <section aria-label="City operations">
          <SecHead title="CITY OPERATIONS" meta={`${cityOps.length} CITIES · PLAN REVENUE ALL TIME`} />
          <ul className="mt-3.5 space-y-4">
            {cityOps.map((c, i) => (
              <li key={c.city}>
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-0.5">
                  <span className="text-[12px] font-bold tracking-[0.1em] text-primary">
                    {c.city.toUpperCase()}
                    {i === 0 && (
                      <span className="ml-2 border border-[#1f3a2b]/45 px-1 py-px align-middle text-[7px] font-bold tracking-[0.1em] text-primary">
                        HQ
                      </span>
                    )}
                  </span>
                  <span className="text-[9px] font-medium tracking-[0.1em] text-muted-foreground/85">
                    {c.customers} HOUSEHOLDS · {c.helpers} HELPERS · {c.placements} PLACED
                  </span>
                  <span className="ml-auto font-mono text-[12px] font-semibold text-primary">
                    {fmtMoney(c.revenue, { compact: true })}
                  </span>
                </div>
                <div className="mt-1.5 h-[4px] bg-[#1f3a2b]/10" aria-hidden="true">
                  <i
                    className="block h-full bg-primary"
                    style={{ width: `${Math.max((c.revenue / maxCityRevenue) * 100, 2)}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </section>

        <section aria-label="Expense breakdown">
          <SecHead title="EXPENSE ABSTRACT" meta={`${periodLabel.toUpperCase()} · BY CATEGORY`} />
          <ul className="mt-3.5 space-y-3">
            {expenseByCategory.map((c) => (
              <li key={c.category}>
                <div className="flex items-end">
                  <span className="caps-label mb-0.5 max-w-[55%] truncate text-foreground">{c.category}</span>
                  <span className="leader" aria-hidden="true" />
                  <span className="mb-0.5 whitespace-nowrap font-mono text-[12px] font-semibold text-primary">
                    {fmtMoney(c.total, { compact: true })}
                  </span>
                </div>
                <div className="mt-1 h-[3px] bg-[#1f3a2b]/8" aria-hidden="true">
                  <i
                    className="block h-full bg-[#b4822a]/70"
                    style={{ width: `${Math.max((c.total / maxExpense) * 100, 2)}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
          <button
            onClick={() => onNavigate?.('reports')}
            className="mt-5 block w-full border border-[#b4822a]/50 bg-[#b4822a]/10 px-3 py-2.5 text-left text-[11px] leading-relaxed text-[#8f6511] transition-colors hover:bg-[#b4822a]/20"
          >
            <b className="font-semibold uppercase tracking-[0.12em]">GST filing reminder</b>
            <br />
            <span className="font-serif italic">
              {fmtMoney(kpis.gstPayable)} output GST collected and payable — see the Balance Sheet for the full liability position.
            </span>
          </button>
        </section>
      </div>
    </div>
  );
}
