'use client';

import { useEffect, useMemo, useState } from 'react';
import { Plus, Receipt, Trash2, RotateCcw, IndianRupee, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { fmtMoney, fmtDate, PlanBadge, LoadingBlock, ErrorNote, MiniStat } from './shared';

interface SaleRow {
  id: string;
  customerId: string;
  customer: { id: string; name: string; city: string; locality: string | null; phone: string | null };
  planType: string;
  feeAmount: number;
  gstRate: number;
  gstAmount: number;
  totalAmount: number;
  paymentMode: string;
  saleDate: string;
  isRefunded: boolean;
  refundAmount: number;
}

interface CustomerOption {
  id: string;
  name: string;
  city: string;
  planType: string | null;
  status: string;
}

const PLAN_FEES: Record<string, number> = { SILVER: 4999, GOLD: 5999, DIAMOND: 6999 };
const PLAN_COVERAGE: Record<string, string> = {
  SILVER: '10 months · 3 placements',
  GOLD: '12 months · 5 placements',
  DIAMOND: '18 months · 10 placements',
};
const PAYMENT_MODES = [
  { value: 'UPI', label: 'UPI' },
  { value: 'BANK', label: 'Bank Transfer' },
  { value: 'CARD', label: 'Card' },
  { value: 'CASH', label: 'Cash' },
];

export function PlanSales() {
  const { toast } = useToast();
  const [sales, setSales] = useState<SaleRow[] | null>(null);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('ALL');
  const [createOpen, setCreateOpen] = useState(false);
  const [refundTarget, setRefundTarget] = useState<SaleRow | null>(null);
  const [refundAmount, setRefundAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [nonRefundablePortion, setNonRefundablePortion] = useState(2000);

  const [form, setForm] = useState({
    customerId: '',
    planType: 'GOLD',
    feeAmount: '5999',
    gstRate: '18',
    paymentMode: 'UPI',
    saleDate: new Date().toISOString().slice(0, 10),
  });

  const load = async () => {
    try {
      setError('');
      const [saleRes, custRes, setRes] = await Promise.all([
        fetch('/api/plan-sales'),
        fetch('/api/customers'),
        fetch('/api/settings'),
      ]);
      if (!saleRes.ok || !custRes.ok) throw new Error();
      const saleJson = await saleRes.json();
      const custJson = await custRes.json();
      setSales(saleJson.sales);
      setCustomers(custJson.customers);
      if (setRes.ok) {
        const setJson = await setRes.json();
        setNonRefundablePortion(Number(setJson.settings?.nonRefundablePortion) || 2000);
      }
    } catch {
      setError('Could not load plan sales. Please refresh.');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    if (!sales) return [];
    return tab === 'ALL'
      ? sales
      : tab === 'REFUNDED'
        ? sales.filter((s) => s.isRefunded)
        : sales.filter((s) => s.planType === tab && !s.isRefunded);
  }, [sales, tab]);

  const totals = useMemo(() => {
    if (!sales) return null;
    return {
      revenue: sales.filter((s) => !s.isRefunded).reduce((s, x) => s + x.feeAmount, 0),
      gst: sales.filter((s) => !s.isRefunded).reduce((s, x) => s + x.gstAmount, 0),
      count: sales.filter((s) => !s.isRefunded).length,
    };
  }, [sales]);

  const computed = useMemo(() => {
    const fee = parseFloat(form.feeAmount) || 0;
    const gst = (fee * (parseFloat(form.gstRate) || 0)) / 100;
    return { fee, gst, total: fee + gst };
  }, [form.feeAmount, form.gstRate]);

  const submit = async () => {
    if (!form.customerId) {
      toast({ title: 'Please select a customer.', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/plan-sales', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: form.customerId,
          planType: form.planType,
          feeAmount: parseFloat(form.feeAmount) || undefined,
          gstRate: parseFloat(form.gstRate),
          paymentMode: form.paymentMode,
          saleDate: form.saleDate,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to record sale');
      toast({
        title: `${form.planType} plan sold — ${fmtMoney(computed.total)} received`,
        description: `Journal entry ${json.journalEntry.entryNumber} posted (revenue + GST).`,
      });
      setCreateOpen(false);
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : 'Failed to record sale', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const refund = async () => {
    if (!refundTarget) return;
    setBusyId(refundTarget.id);
    try {
      const res = await fetch('/api/plan-sales', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: refundTarget.id,
          refundAmount: refundAmount ? parseFloat(refundAmount) : undefined,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to refund');
      toast({
        title: `Refund processed — ${fmtMoney(json.refunded)}`,
        description: 'Refund journal entry posted.',
      });
      setRefundTarget(null);
      setRefundAmount('');
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : 'Failed to refund', variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  };

  if (error) return <ErrorNote message={error} />;
  if (!sales) return <LoadingBlock label="Loading plan sales…" />;

  return (
    <div className="space-y-4">
      {totals && (
        <div className="grid grid-cols-3 gap-x-8 gap-y-4">
          <MiniStat label="PLANS SOLD" value={String(totals.count)} sub="excl. refunded" />
          <MiniStat label="FEE REVENUE" value={fmtMoney(totals.revenue, { compact: true })} sub="excl. GST · all time" />
          <MiniStat label="GST COLLECTED" value={fmtMoney(totals.gst, { compact: true })} sub="output tax on platform fees" />
        </div>
      )}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="ALL" className="text-xs sm:text-sm">All</TabsTrigger>
            <TabsTrigger value="SILVER" className="text-xs sm:text-sm">Silver</TabsTrigger>
            <TabsTrigger value="GOLD" className="text-xs sm:text-sm">Gold</TabsTrigger>
            <TabsTrigger value="DIAMOND" className="text-xs sm:text-sm">Diamond</TabsTrigger>
            <TabsTrigger value="REFUNDED" className="text-xs sm:text-sm">Refunded</TabsTrigger>
          </TabsList>
        </Tabs>
        <Button onClick={() => setCreateOpen(true)} className="shrink-0">
          <Plus className="mr-2 h-4 w-4" /> Record Plan Sale
        </Button>
      </div>

      <Card className="py-0">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="rule-double-b text-left text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
                  <th className="px-6 py-3 font-bold">Date</th>
                  <th className="px-4 py-3 font-bold">Customer</th>
                  <th className="px-4 py-3 font-bold">Plan</th>
                  <th className="hidden px-4 py-3 text-right font-bold sm:table-cell">Fee</th>
                  <th className="hidden px-4 py-3 text-right font-bold md:table-cell">GST</th>
                  <th className="px-4 py-3 text-right font-bold">Total</th>
                  <th className="hidden px-4 py-3 font-bold lg:table-cell">Paid via</th>
                  <th className="px-6 py-3 text-right font-bold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr
                    key={s.id}
                    className={`border-b last:border-0 transition-colors hover:bg-muted/40 ${s.isRefunded ? 'opacity-60' : ''}`}
                  >
                    <td className="whitespace-nowrap px-6 py-3 text-muted-foreground">{fmtDate(s.saleDate)}</td>
                    <td className="px-4 py-3">
                      <p className="font-medium">{s.customer.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {s.customer.locality ? `${s.customer.locality}, ` : ''}
                        {s.customer.city}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <PlanBadge plan={s.planType} />
                    </td>
                    <td className="hidden px-4 py-3 text-right tabular-nums sm:table-cell">
                      {fmtMoney(s.feeAmount)}
                    </td>
                    <td className="hidden px-4 py-3 text-right tabular-nums text-muted-foreground md:table-cell">
                      {fmtMoney(s.gstAmount)}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold tabular-nums">
                      {fmtMoney(s.totalAmount)}
                      {s.isRefunded && (
                        <p className="text-xs font-normal text-rose-600 dark:text-rose-400">
                          refunded {fmtMoney(s.refundAmount)}
                        </p>
                      )}
                    </td>
                    <td className="hidden px-4 py-3 text-muted-foreground lg:table-cell">{s.paymentMode}</td>
                    <td className="px-6 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8"
                          onClick={() => window.open(`/receipt/${s.id}`, '_blank')}
                          title="View / print GST receipt"
                        >
                          <Printer className="mr-1 h-3.5 w-3.5" /> Receipt
                        </Button>
                        {!s.isRefunded && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-rose-600 hover:text-rose-700 dark:text-rose-400"
                            disabled={busyId === s.id}
                            onClick={() => {
                              setRefundTarget(s);
                              setRefundAmount(
                                String(
                                  Math.round(
                                    Math.max(0, s.feeAmount - nonRefundablePortion) * 100
                                  ) / 100
                                )
                              );
                            }}
                          >
                            <RotateCcw className="mr-1 h-3.5 w-3.5" /> Refund
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-muted-foreground">
                      <Receipt className="mx-auto mb-2 h-8 w-8" />
                      <p className="text-sm font-medium">No plan sales found</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Record Plan Sale</DialogTitle>
            <DialogDescription>
              Revenue and GST journal entries are posted automatically.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Customer</Label>
              <Select value={form.customerId} onValueChange={(v) => setForm({ ...form, customerId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select customer…" />
                </SelectTrigger>
                <SelectContent className="max-h-64">
                  {customers.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name} — {c.city}
                      {c.planType ? ` (${c.planType.toLowerCase()})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Plan</Label>
              <div className="grid grid-cols-3 gap-2">
                {(['SILVER', 'GOLD', 'DIAMOND'] as const).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setForm({ ...form, planType: p, feeAmount: String(PLAN_FEES[p]) })}
                    className={`rounded-lg border p-3 text-left transition-colors ${
                      form.planType === p
                        ? 'border-emerald-600 bg-emerald-50 dark:border-emerald-500 dark:bg-emerald-950'
                        : 'hover:bg-muted/60'
                    }`}
                  >
                    <p className="text-sm font-semibold capitalize">{p}</p>
                    <p className="text-xs text-muted-foreground">₹{PLAN_FEES[p].toLocaleString('en-IN')}</p>
                    <p className="mt-1 text-[11px] leading-tight text-muted-foreground">{PLAN_COVERAGE[p]}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="fee">Fee amount (₹)</Label>
                <Input
                  id="fee"
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.feeAmount}
                  onChange={(e) => setForm({ ...form, feeAmount: e.target.value })}
                  className="text-right tabular-nums"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="gst">GST rate (%)</Label>
                <Input
                  id="gst"
                  type="number"
                  min="0"
                  step="0.5"
                  value={form.gstRate}
                  onChange={(e) => setForm({ ...form, gstRate: e.target.value })}
                  className="text-right tabular-nums"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Paid via</Label>
                <Select value={form.paymentMode} onValueChange={(v) => setForm({ ...form, paymentMode: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAYMENT_MODES.map((p) => (
                      <SelectItem key={p.value} value={p.value}>
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sale-date">Sale date</Label>
                <Input
                  id="sale-date"
                  type="date"
                  value={form.saleDate}
                  onChange={(e) => setForm({ ...form, saleDate: e.target.value })}
                />
              </div>
            </div>

            <div className="rounded-lg border bg-muted/40 p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Plan fee</span>
                <span className="tabular-nums">{fmtMoney(computed.fee)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">GST ({form.gstRate}%)</span>
                <span className="tabular-nums">{fmtMoney(computed.gst)}</span>
              </div>
              <div className="mt-1 flex justify-between border-t pt-1.5 font-semibold">
                <span className="flex items-center gap-1">
                  <IndianRupee className="h-3.5 w-3.5" /> Total collected
                </span>
                <span className="tabular-nums">{fmtMoney(computed.total)}</span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? 'Recording…' : 'Record Sale'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* refund dialog */}
      <Dialog open={!!refundTarget} onOpenChange={(o) => !o && setRefundTarget(null)}>
        <DialogContent className="sm:max-w-md">
          {refundTarget && (
            <>
              <DialogHeader>
                <DialogTitle>Refund Plan Sale</DialogTitle>
                <DialogDescription>
                  {refundTarget.customer.name} — {refundTarget.planType} plan, {fmtDate(refundTarget.saleDate)}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="rounded-lg border bg-amber-50 p-3 text-sm text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  <p>
                    Per policy, ₹{nonRefundablePortion.toLocaleString('en-IN')} of every plan fee is
                    non-refundable (covers onboarding & verification). Maximum refundable:{' '}
                    <strong>
                      ₹{Math.round(Math.max(0, refundTarget.feeAmount - nonRefundablePortion) * 100) / 100}
                    </strong>
                    .
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="refund-amt">Refund amount (₹)</Label>
                  <Input
                    id="refund-amt"
                    type="number"
                    min="0"
                    step="0.01"
                    value={refundAmount}
                    onChange={(e) => setRefundAmount(e.target.value)}
                    className="text-right tabular-nums"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setRefundTarget(null)}>
                  Cancel
                </Button>
                <Button variant="destructive" onClick={refund} disabled={busyId === refundTarget.id}>
                  {busyId === refundTarget.id ? 'Processing…' : 'Process Refund'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
