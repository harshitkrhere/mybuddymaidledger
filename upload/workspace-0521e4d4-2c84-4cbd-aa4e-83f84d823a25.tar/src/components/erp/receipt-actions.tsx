'use client';

import { Printer, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function ReceiptActions({ saleId }: { saleId: string }) {
  const print = () => window.print();

  return (
    <div className="no-print flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-4 py-3 sm:px-8">
      <Button variant="ghost" size="sm" onClick={() => history.back()}>
        <ArrowLeft className="mr-1.5 h-4 w-4" />
        Back to ERP
      </Button>
      <p className="hidden text-xs text-muted-foreground sm:block">
        Receipt ID {saleId.slice(0, 8).toUpperCase()}
      </p>
      <Button size="sm" onClick={print}>
        <Printer className="mr-1.5 h-4 w-4" />
        Print / Save as PDF
      </Button>
    </div>
  );
}
