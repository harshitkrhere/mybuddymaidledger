'use client';

import { cn } from '@/lib/utils';

// =============================
// Formatting helpers — INR
// =============================

export function fmtMoney(n: number | null | undefined, opts?: { sign?: boolean; compact?: boolean }): string {
  if (n == null || isNaN(n)) return '—';
  const { sign = false, compact = false } = opts || {};
  const abs = Math.abs(n);
  let body: string;
  if (compact && abs >= 1000) {
    body = new Intl.NumberFormat('en-IN', {
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(abs);
  } else {
    body = abs.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  const prefix = n < 0 ? '−' : sign ? '+' : '';
  return `${prefix}₹${body}`;
}

export function fmtDate(d: string | Date): string {
  const date = typeof d === 'string' ? new Date(d) : d;
  return date.toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
}

export function fmtMonth(d: string | Date): string {
  const date = typeof d === 'string' ? new Date(d) : d;
  return date.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
}

export function toInputDate(d: string | Date): string {
  const date = typeof d === 'string' ? new Date(d) : d;
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

// =============================
// Ledger tags (rectangular, micro-caps — no pill badges)
// =============================

const TAG_BASE =
  'inline-flex items-center whitespace-nowrap border px-1.5 py-px text-[10px] font-semibold uppercase leading-4 tracking-[0.1em]';

const TYPE_TAG: Record<string, string> = {
  ASSET: 'border-[#1f3a2b]/45 text-primary bg-[#1f3a2b]/5',
  LIABILITY: 'border-[#8f3b2e]/50 text-[#8f3b2e]',
  EQUITY: 'border-[#8f6511]/50 text-[#8f6511]',
  REVENUE: 'border-[#476b57]/55 text-[#476b57] bg-[#476b57]/5',
  EXPENSE: 'border-[#b4822a]/60 text-[#8f6511] bg-[#b4822a]/10',
};

export function AccountTypeBadge({ type }: { type: string }) {
  return <span className={cn(TAG_BASE, TYPE_TAG[type] || 'border-border text-muted-foreground')}>{type}</span>;
}

const PLAN_TAG: Record<string, string> = {
  SILVER: 'border-[#476b57]/45 text-[#476b57]',
  GOLD: 'border-[#8f6511]/50 text-[#8f6511]',
  DIAMOND: 'border-[#b4822a]/60 text-[#8f6511] bg-[#b4822a]/10',
};

export function PlanBadge({ plan }: { plan: string }) {
  return (
    <span className={cn(TAG_BASE, 'normal-case tracking-normal', PLAN_TAG[plan] || 'border-border text-muted-foreground')}>
      {plan.toLowerCase()}
    </span>
  );
}

const CUST_TAG: Record<string, string> = {
  ACTIVE: 'border-[#1f3a2b]/45 text-primary bg-[#1f3a2b]/5',
  EXPIRED: 'border-border text-muted-foreground',
  REFUNDED: 'border-[#8f3b2e]/50 text-[#8f3b2e]',
};

export function CustomerStatusBadge({ status }: { status: string }) {
  return <span className={cn(TAG_BASE, CUST_TAG[status] || 'border-border text-muted-foreground')}>{status}</span>;
}

const HELPER_TAG: Record<string, string> = {
  VERIFIED: 'border-[#1f3a2b]/45 text-primary bg-[#1f3a2b]/5',
  PLACED: 'border-[#476b57]/55 text-[#476b57] bg-[#476b57]/5',
  PENDING: 'border-[#b4822a]/60 text-[#8f6511] bg-[#b4822a]/10',
  INACTIVE: 'border-border text-muted-foreground',
};

export function HelperStatusBadge({ status }: { status: string }) {
  return <span className={cn(TAG_BASE, HELPER_TAG[status] || 'border-border text-muted-foreground')}>{status}</span>;
}

const PLACE_TAG: Record<string, string> = {
  ACTIVE: 'border-[#1f3a2b]/45 text-primary bg-[#1f3a2b]/5',
  ENDED: 'border-border text-muted-foreground',
  REPLACED: 'border-[#b4822a]/60 text-[#8f6511] bg-[#b4822a]/10',
};

export function PlacementStatusBadge({ status }: { status: string }) {
  return <span className={cn(TAG_BASE, PLACE_TAG[status] || 'border-border text-muted-foreground')}>{status}</span>;
}

const SOURCE_TAG: Record<string, string> = {
  MANUAL: 'border-border text-muted-foreground',
  PLAN_SALE: 'border-[#476b57]/55 text-[#476b57] bg-[#476b57]/5',
  EXPENSE: 'border-[#b4822a]/60 text-[#8f6511] bg-[#b4822a]/10',
  REFUND: 'border-[#8f3b2e]/50 text-[#8f3b2e]',
  OPENING: 'border-[#8f6511]/50 text-[#8f6511]',
};

export function SourceBadge({ source }: { source: string }) {
  return (
    <span className={cn(TAG_BASE, SOURCE_TAG[source] || 'border-border text-muted-foreground')}>
      {source.replaceAll('_', ' ')}
    </span>
  );
}

// =============================
// Section heads — square bullet, serif italic, hairline rule
// =============================

export function SecHead({
  title,
  italic,
  meta,
  action,
  className,
}: {
  title: string;
  italic?: string;
  meta?: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('rule-top flex flex-wrap items-baseline gap-x-3 gap-y-1.5 pt-3', className)}>
      <h2 className="flex items-baseline gap-2 text-[11px] font-bold uppercase tracking-[0.17em] text-primary">
        <span className="mb-px inline-block h-[7px] w-[7px] shrink-0 self-center bg-primary" aria-hidden="true" />
        {title}
        {italic && (
          <i className="font-serif text-xs font-normal normal-case italic tracking-normal text-muted-foreground">
            {italic}
          </i>
        )}
      </h2>
      {meta && (
        <span className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground/80">{meta}</span>
      )}
      {action && <div className="ml-auto flex items-center gap-2">{action}</div>}
    </div>
  );
}

// =============================
// Loading & empty states
// =============================

export function LoadingBlock({ label = 'Posting the books…' }: { label?: string }) {
  return (
    <div className="rule-top flex h-48 items-center justify-center pt-4">
      <span className="animate-pulse font-serif text-sm italic text-muted-foreground">{label}</span>
    </div>
  );
}

export function EmptyState({
  title,
  hint,
  action,
}: {
  title: string;
  hint?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="rule-top flex flex-col items-center justify-center gap-2 border-b border-dashed border-[#1f3a2b]/25 p-10 pt-6 text-center">
      <p className="font-serif text-base italic">{title}</p>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
      {action}
    </div>
  );
}

export function ErrorNote({ message }: { message: string }) {
  return (
    <div className="rule-double border-b border-[#8f3b2e]/40 bg-[#8f3b2e]/5 px-4 py-3 text-sm text-[#8f3b2e]">
      {message}
    </div>
  );
}

// =============================
// Figure blocks (replaces rounded KPI cards)
// =============================

export function KpiCard({
  label,
  value,
  sub,
  tone = 'default',
  icon,
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: 'default' | 'positive' | 'negative' | 'warning';
  icon?: React.ReactNode;
}) {
  const tones = {
    default: 'text-foreground',
    positive: 'text-primary',
    negative: 'text-[#8f3b2e]',
    warning: 'text-[#8f6511]',
  };
  return (
    <div className="rule-top pt-3">
      <div className="flex items-center justify-between gap-2">
        <p className="caps-label flex items-center gap-2 text-primary">
          <span className="inline-block h-[7px] w-[7px] bg-primary" aria-hidden="true" />
          {label}
        </p>
        {icon && <span className="text-muted-foreground/70 [&>svg]:h-3.5 [&>svg]:w-3.5">{icon}</span>}
      </div>
      <p className={cn('mt-2.5 font-serif text-2xl font-semibold leading-none tabular-nums sm:text-[28px]', tones[tone])}>
        {value}
      </p>
      {sub && <p className="mt-2 text-[11px] font-medium tracking-wide text-muted-foreground">{sub}</p>}
    </div>
  );
}

export function MiniStat({
  label,
  value,
  sub,
  icon,
}: {
  label: string;
  value: string;
  sub?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="rule-top pt-3">
      <div className="flex items-start justify-between gap-2">
        <p className="caps-label text-primary">{label}</p>
        {icon && <span className="text-muted-foreground/70 [&>svg]:h-4 [&>svg]:w-4">{icon}</span>}
      </div>
      <p className="mt-1.5 font-serif text-[34px] font-semibold leading-none tabular-nums text-foreground">{value}</p>
      {sub && <p className="mt-1.5 font-serif text-xs italic text-muted-foreground">{sub}</p>}
    </div>
  );
}

// =============================
// Dotted-leader stat (ledger abstract style)
// =============================

export function DottedStat({
  label,
  value,
  sub,
  tone = 'default',
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: 'default' | 'negative' | 'warning' | 'positive';
}) {
  const tones = {
    default: 'text-foreground',
    positive: 'text-primary',
    negative: 'text-[#8f6511]',
    warning: 'text-[#8f6511]',
  };
  return (
    <div>
      <div className="flex items-end">
        <span className="caps-label pb-1 text-muted-foreground">{label}</span>
        <span className="leader" aria-hidden="true" />
        <span className={cn('whitespace-nowrap font-serif text-xl font-semibold leading-none tabular-nums sm:text-2xl', tones[tone])}>
          {value}
        </span>
      </div>
      {sub && (
        <p className="mt-1.5 text-right text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground/85">
          {sub}
        </p>
      )}
    </div>
  );
}
