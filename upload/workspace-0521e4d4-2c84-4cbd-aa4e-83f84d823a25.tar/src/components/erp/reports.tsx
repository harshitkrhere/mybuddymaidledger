'use client';

import { useEffect, useState } from 'react';
import { FileBarChart, CheckCircle2, Scale, CalendarRange } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { fmtMoney, LoadingBlock, ErrorNote } from './shared';
import { cn } from '@/lib/utils';

interface AccountBalance {
  id: string;
  code: string;
  name: string;
  type: string;
  balance: number;
}

interface PLData {
  type: 'pl';
  range: { from: string | null; to: string | null; label: string };
  revenue: AccountBalance[];
  expenses: AccountBalance[];
  totalRevenue: number;
  totalExpenses: number;
  netIncome: number;
  margin: number;
  months: { label: string; revenue: number; expenses: number; net: number }[];
}

interface BalanceData {
  type: 'balance';
  assets: AccountBalance[];
  liabilities: AccountBalance[];
  equity: AccountBalance[];
  netIncome: number;
  totalRevenue: number;
  totalExpenses: number;
  totalAssets: number;
  totalLiabilities: number;
  totalEquity: number;
  balanced: boolean;
}

interface TrialData {
  type: 'trial';
  rows: { code: string; name: string; type: string; debit: number; credit: number }[];
  totalDebit: number;
  totalCredit: number;
  balanced: boolean;
}

type ReportData = PLData | BalanceData | TrialData;

function isoDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function fyRange(): { from: string; to: string } {
  const now = new Date();
  const apr1 = new Date(now.getFullYear(), 3, 1);
  const start = now >= apr1 ? apr1 : new Date(now.getFullYear() - 1, 3, 1);
  const end = new Date(start.getFullYear() + 1, 3, 0); // Mar 31
  return { from: isoDate(start), to: isoDate(end) };
}

const RANGE_PRESETS: { key: string; label: string; compute: () => { from: string; to: string } | null }[] = [
  {
    key: 'all',
    label: 'All Time',
    compute: () => null,
  },
  {
    key: 'fy',
    label: 'This FY',
    compute: () => fyRange(),
  },
  {
    key: 'month',
    label: 'This Month',
    compute: () => {
      const now = new Date();
      return {
        from: isoDate(new Date(now.getFullYear(), now.getMonth(), 1)),
        to: isoDate(new Date(now.getFullYear(), now.getMonth() + 1, 0)),
      };
    },
  },
];

export function Reports() {
  const { toast } = useToast();
  const [tab, setTab] = useState('pl');
  const [data, setData] = useState<ReportData | null>(null);
  const [error, setError] = useState('');
  const [rangeKey, setRangeKey] = useState('all');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');

  const load = async (type: string) => {
    try {
      setError('');
      let qs = `type=${type}`;
      if (type === 'pl') {
        if (rangeKey === 'custom') {
          if (customFrom) qs += `&from=${customFrom}`;
          if (customTo) qs += `&to=${customTo}`;
        } else {
          const preset = RANGE_PRESETS.find((p) => p.key === rangeKey);
          const r = preset?.compute() ?? null;
          if (r) qs += `&from=${r.from}&to=${r.to}`;
        }
      }
      const res = await fetch(`/api/reports?${qs}`);
      if (!res.ok) throw new Error();
      setData(await res.json());
    } catch {
      setError('Could not generate report. Please refresh.');
    }
  };

  useEffect(() => {
    load(tab);
  }, [tab, rangeKey, customFrom, customTo]);

  const exportCsv = () => {
    if (!data) return;
    let csv = '';
    if (data.type === 'pl') {
      csv = `Profit and Loss,${data.range?.label ?? 'All time'}\n\n`;
      csv += 'Section,Code,Account,Amount\n';
      csv += data.revenue.map((r) => `Revenue,${r.code},"${r.name}",${r.balance}`).join('\n') + '\n';
      csv += `,,Total Revenue,${data.totalRevenue}\n`;
      csv += data.expenses.map((r) => `Expenses,${r.code},"${r.name}",${r.balance}`).join('\n') + '\n';
      csv += `,,Total Expenses,${data.totalExpenses}\n`;
      csv += `,,Net Income,${data.netIncome}\n`;
    } else if (data.type === 'balance') {
      csv = 'Section,Code,Account,Amount\n';
      csv += data.assets.map((r) => `Assets,${r.code},"${r.name}",${r.balance}`).join('\n') + '\n';
      csv += `,,Total Assets,${data.totalAssets}\n`;
      csv += data.liabilities.map((r) => `Liabilities,${r.code},"${r.name}",${r.balance}`).join('\n') + '\n';
      csv += `,,Total Liabilities,${data.totalLiabilities}\n`;
      csv += data.equity.map((r) => `Equity,${r.code},"${r.name}",${r.balance}`).join('\n') + '\n';
      csv += `,,Net Income,${data.netIncome}\n`;
      csv += `,,Total Equity,${data.totalEquity}\n`;
    } else {
      csv = 'Code,Account,Type,Debit,Credit\n';
      csv += data.rows
        .map((r) => `${r.code},"${r.name}",${r.type},${r.debit},${r.credit}`)
        .join('\n') + '\n';
      csv += `,,Totals,${data.totalDebit},${data.totalCredit}\n`;
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${data.type === 'pl' ? 'profit-and-loss' : data.type === 'balance' ? 'balance-sheet' : 'trial-balance'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'CSV exported' });
  };

  if (error) return <ErrorNote message={error} />;
  if (!data) return <LoadingBlock label="Generating report…" />;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="pl">Profit & Loss</TabsTrigger>
            <TabsTrigger value="balance">Balance Sheet</TabsTrigger>
            <TabsTrigger value="trial">Trial Balance</TabsTrigger>
          </TabsList>
        </Tabs>
        <Button variant="outline" onClick={exportCsv}>
          Export CSV
        </Button>
      </div>

      {/* Date range toolbar — P&L only (balance sheet & trial balance are point-in-time) */}
      {tab === 'pl' && (
        <div className="flex flex-col gap-3 rounded-xl border bg-card p-3 sm:flex-row sm:items-center sm:flex-wrap">
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <CalendarRange className="h-3.5 w-3.5" />
            Period
          </div>
          <div className="flex flex-wrap gap-1.5">
            {RANGE_PRESETS.map((p) => (
              <button
                key={p.key}
                onClick={() => setRangeKey(p.key)}
                className={cn(
                  'rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors',
                  rangeKey === p.key
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                )}
                aria-pressed={rangeKey === p.key}
              >
                {p.label}
              </button>
            ))}
            <button
              onClick={() => setRangeKey('custom')}
              className={cn(
                'rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors',
                rangeKey === 'custom'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:text-foreground'
              )}
              aria-pressed={rangeKey === 'custom'}
            >
              Custom
            </button>
          </div>
          {rangeKey === 'custom' && (
            <div className="flex items-center gap-2">
              <Input
                type="date"
                value={customFrom}
                onChange={(e) => setCustomFrom(e.target.value)}
                className="h-8 w-36 text-xs"
                aria-label="From date"
              />
              <span className="text-xs text-muted-foreground">to</span>
              <Input
                type="date"
                value={customTo}
                onChange={(e) => setCustomTo(e.target.value)}
                className="h-8 w-36 text-xs"
                aria-label="To date"
              />
            </div>
          )}
          {data?.type === 'pl' && data.range && (
            <p className="text-xs text-muted-foreground sm:ml-auto">{data.range.label}</p>
          )}
        </div>
      )}

      {/* ===== P&L ===== */}
      {data.type === 'pl' && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Profit & Loss Statement</CardTitle>
              <CardDescription>
                Income statement · {data.range?.label ?? 'All time'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <section>
                <h3 className="mb-2 caps-label text-primary">
                  Revenue
                </h3>
                <ul className="space-y-1">
                  {data.revenue.map((r) => (
                    <li key={r.id} className="flex items-baseline justify-between border-b border-dashed py-1 text-sm">
                      <span className="text-muted-foreground">
                        <span className="mr-2 font-mono text-xs">{r.code}</span>
                        {r.name}
                      </span>
                      <span className="tabular-nums">{fmtMoney(r.balance)}</span>
                    </li>
                  ))}
                  {data.revenue.length === 0 && (
                    <li className="py-1 text-sm text-muted-foreground">No revenue recorded.</li>
                  )}
                </ul>
                <div className="mt-2 flex justify-between border-t pt-2 text-sm font-semibold">
                  <span>Total Revenue</span>
                  <span className="tabular-nums">{fmtMoney(data.totalRevenue)}</span>
                </div>
              </section>

              <section>
                <h3 className="mb-2 text-sm font-semibold uppercase tracking-wide text-orange-700 dark:text-orange-300">
                  Expenses
                </h3>
                <ul className="space-y-1">
                  {data.expenses.map((r) => (
                    <li key={r.id} className="flex items-baseline justify-between border-b border-dashed py-1 text-sm">
                      <span className="text-muted-foreground">
                        <span className="mr-2 font-mono text-xs">{r.code}</span>
                        {r.name}
                      </span>
                      <span className="tabular-nums">{fmtMoney(r.balance)}</span>
                    </li>
                  ))}
                  {data.expenses.length === 0 && (
                    <li className="py-1 text-sm text-muted-foreground">No expenses recorded.</li>
                  )}
                </ul>
                <div className="mt-2 flex justify-between border-t pt-2 text-sm font-semibold">
                  <span>Total Expenses</span>
                  <span className="tabular-nums">{fmtMoney(data.totalExpenses)}</span>
                </div>
              </section>

              <div
                className={cn(
                  'flex items-center justify-between rounded-xl border p-4',
                  data.netIncome >= 0
                    ? 'border-[#1f3a2b]/25 bg-[#1f3a2b]/5'
                    : 'border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950'
                )}
              >
                <div>
                  <p className="text-sm font-semibold">Net Income</p>
                  <p className="text-xs text-muted-foreground">Profit margin {data.margin.toFixed(1)}%</p>
                </div>
                <p
                  className={cn(
                    'text-2xl font-bold tabular-nums',
                    data.netIncome >= 0 ? 'text-primary' : 'text-[#8f6511]'
                  )}
                >
                  {fmtMoney(data.netIncome, { sign: true })}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Trend</CardTitle>
              <CardDescription>
                {data.range && (data.range.from || data.range.to)
                  ? 'Months within selected period (max 12)'
                  : 'Last 6 months'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1">
                {data.months.map((m) => {
                  const max = Math.max(...data.months.map((x) => Math.max(x.revenue, x.expenses)), 1);
                  return (
                    <li key={m.label} className="space-y-1 rounded-lg p-2 hover:bg-muted/40">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">{m.label}</span>
                        <span
                          className={cn(
                            'font-semibold tabular-nums',
                            m.net >= 0 ? 'text-primary' : 'text-[#8f6511]'
                          )}
                        >
                          {fmtMoney(m.net, { sign: true })}
                        </span>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                            <div
                              className="h-full bg-primary"
                              style={{ width: `${(m.revenue / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-16 text-right text-xs tabular-nums text-muted-foreground">
                            {fmtMoney(m.revenue, { compact: true })}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                            <div
                              className="h-full rounded-full bg-rose-500"
                              style={{ width: `${(m.expenses / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-16 text-right text-xs tabular-nums text-muted-foreground">
                            {fmtMoney(m.expenses, { compact: true })}
                          </span>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ===== Balance Sheet ===== */}
      {data.type === 'balance' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Assets</CardTitle>
              <CardDescription>What the business owns</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1">
                {data.assets.map((a) => (
                  <li key={a.id} className="flex items-baseline justify-between border-b border-dashed py-1.5 text-sm">
                    <span className="text-muted-foreground">
                      <span className="mr-2 font-mono text-xs">{a.code}</span>
                      {a.name}
                    </span>
                    <span className="tabular-nums">{fmtMoney(a.balance)}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-3 flex justify-between border-t-2 pt-2.5 font-semibold">
                <span>Total Assets</span>
                <span className="tabular-nums text-primary">
                  {fmtMoney(data.totalAssets)}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Liabilities & Equity</CardTitle>
              <CardDescription>What the business owes and owners' stake</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div>
                <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Liabilities
                </h3>
                <ul className="space-y-1">
                  {data.liabilities.map((l) => (
                    <li key={l.id} className="flex items-baseline justify-between border-b border-dashed py-1.5 text-sm">
                      <span className="text-muted-foreground">
                        <span className="mr-2 font-mono text-xs">{l.code}</span>
                        {l.name}
                      </span>
                      <span className="tabular-nums">{fmtMoney(l.balance)}</span>
                    </li>
                  ))}
                  {data.liabilities.length === 0 && (
                    <li className="py-1 text-sm text-muted-foreground">No liabilities.</li>
                  )}
                </ul>
                <div className="mt-2 flex justify-between border-t pt-2 text-sm font-semibold">
                  <span>Total Liabilities</span>
                  <span className="tabular-nums text-rose-600 dark:text-rose-400">
                    {fmtMoney(data.totalLiabilities)}
                  </span>
                </div>
              </div>
              <div>
                <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Equity
                </h3>
                <ul className="space-y-1">
                  {data.equity.map((e) => (
                    <li key={e.id} className="flex items-baseline justify-between border-b border-dashed py-1.5 text-sm">
                      <span className="text-muted-foreground">
                        <span className="mr-2 font-mono text-xs">{e.code}</span>
                        {e.name}
                      </span>
                      <span className="tabular-nums">{fmtMoney(e.balance)}</span>
                    </li>
                  ))}
                  <li className="flex items-baseline justify-between border-b border-dashed py-1.5 text-sm">
                    <span className="text-muted-foreground">Current-period Net Income</span>
                    <span className="tabular-nums">{fmtMoney(data.netIncome)}</span>
                  </li>
                </ul>
                <div className="mt-2 flex justify-between border-t pt-2 text-sm font-semibold">
                  <span>Total Equity</span>
                  <span className="tabular-nums">{fmtMoney(data.totalEquity)}</span>
                </div>
              </div>
              <div className="flex items-center justify-between rounded-xl border bg-muted/40 p-3.5">
                <span className="text-sm font-semibold">Liabilities + Equity</span>
                <span className="font-bold tabular-nums">{fmtMoney(data.totalLiabilities + data.totalEquity)}</span>
              </div>
            </CardContent>
          </Card>

          <div
            className={cn(
              'flex items-center gap-3 rounded-xl border p-4 lg:col-span-2',
              data.balanced
                ? 'border-[#1f3a2b]/25 bg-[#1f3a2b]/5'
                : 'border-rose-200 bg-rose-50 dark:border-rose-900 dark:bg-rose-950'
            )}
          >
            {data.balanced ? (
              <CheckCircle2 className="h-5 w-5 shrink-0 text-primary" />
            ) : (
              <Scale className="h-5 w-5 shrink-0 text-rose-600 dark:text-rose-400" />
            )}
            <div>
              <p className="text-sm font-semibold">
                {data.balanced ? 'Balance sheet is balanced' : 'Balance sheet out of balance'}
              </p>
              <p className="text-xs text-muted-foreground">
                Assets {fmtMoney(data.totalAssets)} {data.balanced ? '=' : '≠'} Liabilities + Equity{' '}
                {fmtMoney(data.totalLiabilities + data.totalEquity)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ===== Trial Balance ===== */}
      {data.type === 'trial' && (
        <Card className="py-0">
          <CardHeader className="px-6 pt-6">
            <CardTitle>Trial Balance</CardTitle>
            <CardDescription>All accounts with net debit or credit position</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-6 py-3 font-medium">Code</th>
                    <th className="px-4 py-3 font-medium">Account</th>
                    <th className="hidden px-4 py-3 font-medium sm:table-cell">Type</th>
                    <th className="px-4 py-3 text-right font-medium">Debit</th>
                    <th className="px-6 py-3 text-right font-medium">Credit</th>
                  </tr>
                </thead>
                <tbody>
                  {data.rows.map((r) => (
                    <tr key={r.code} className="border-b last:border-0 transition-colors hover:bg-muted/40">
                      <td className="px-6 py-2.5 font-mono text-xs">{r.code}</td>
                      <td className="px-4 py-2.5 font-medium">{r.name}</td>
                      <td className="hidden px-4 py-2.5 text-muted-foreground sm:table-cell">{r.type}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">
                        {r.debit ? fmtMoney(r.debit) : ''}
                      </td>
                      <td className="px-6 py-2.5 text-right tabular-nums">
                        {r.credit ? fmtMoney(r.credit) : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr
                    className={cn(
                      'border-t-2 font-semibold',
                      data.balanced ? 'bg-[#1f3a2b]/5' : 'bg-[#8f3b2e]/5'
                    )}
                  >
                    <td className="px-6 py-3" colSpan={3}>
                      <span className="flex items-center gap-2">
                        {data.balanced && <CheckCircle2 className="h-4 w-4 text-primary" />}
                        Totals {data.balanced ? '(balanced)' : '(OUT OF BALANCE)'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{fmtMoney(data.totalDebit)}</td>
                    <td className="px-6 py-3 text-right tabular-nums">{fmtMoney(data.totalCredit)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
