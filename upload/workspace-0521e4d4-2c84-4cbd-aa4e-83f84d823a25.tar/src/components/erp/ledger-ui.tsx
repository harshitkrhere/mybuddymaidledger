'use client';

import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';

// =============================
// Brand seal — rubber-stamp SVG
// =============================

export function Seal({ size = 42, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 44 44"
      aria-hidden="true"
      className={cn('shrink-0 -rotate-6 opacity-95', className)}
    >
      <defs>
        <path id="sealArc" d="M 22,6.5 A 15.5,15.5 0 1 1 21.99,6.5" />
      </defs>
      <circle cx="22" cy="22" r="20.4" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="22" cy="22" r="16.4" fill="none" stroke="currentColor" strokeWidth="0.6" opacity=".5" />
      <text fontSize="4.2" letterSpacing="1" fill="currentColor" fontWeight="600" fontFamily="var(--font-archivo), sans-serif">
        <textPath href="#sealArc" startOffset="6">
          MYBUDDYMAID · PATNA ·
        </textPath>
      </text>
      <text
        x="22"
        y="25.8"
        textAnchor="middle"
        fontFamily="var(--font-fraunces), serif"
        fontSize="11"
        fontWeight="600"
        fill="currentColor"
        letterSpacing=".8"
      >
        MBM
      </text>
    </svg>
  );
}

// =============================
// Masthead — broadsheet brand bar
// =============================

export function Masthead() {
  const [clock, setClock] = useState('');

  useEffect(() => {
    const tick = () =>
      setClock(
        new Date().toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
          timeZone: 'Asia/Kolkata',
        }) + ' IST'
      );
    tick();
    const t = setInterval(tick, 30_000);
    return () => clearInterval(t);
  }, []);

  return (
    <header className="flex items-center gap-4 px-4 py-3 sm:px-6 lg:px-10">
      <div className="flex min-w-0 items-center gap-3 text-primary sm:gap-4">
        <Seal size={38} className="hidden sm:block" />
        <div className="min-w-0">
          <p className="truncate font-serif text-lg font-semibold uppercase leading-none tracking-[0.14em] text-primary sm:text-xl">
            MyBuddyMaid
          </p>
          <p className="mt-1.5 hidden text-[9px] font-medium uppercase tracking-[0.22em] text-muted-foreground sm:block">
            Accounts &amp; Operations · Field-Service Books · Est. 2023
          </p>
        </div>
      </div>

      <div className="ml-auto flex items-center gap-4 sm:gap-6">
        <p
          suppressHydrationWarning
          className="hidden whitespace-nowrap text-[9px] font-medium uppercase tracking-[0.17em] text-muted-foreground/80 lg:block"
        >
          Synced {clock || '· · ·'} · Double Entry
        </p>
        <div className="hidden items-center gap-2.5 border-b border-[#1f3a2b]/40 pb-1.5 md:flex">
          <input
            type="search"
            aria-label="Search ledger, customers, helpers"
            placeholder="Search ledger, customers, helpers…"
            className="w-48 bg-transparent font-serif text-[13px] italic text-foreground placeholder:text-muted-foreground/70 focus:outline-none lg:w-56"
          />
          <span className="border border-[#1f3a2b]/25 px-1.5 py-px font-mono text-[9px] text-muted-foreground">⌘K</span>
        </div>
        <div className="flex items-center gap-2.5">
          <span
            aria-hidden="true"
            className="flex h-8 w-8 items-center justify-center bg-primary font-serif text-[11px] font-semibold tracking-wide text-primary-foreground"
          >
            AV
          </span>
          <div className="hidden leading-tight sm:block">
            <p className="text-[9px] font-semibold tracking-[0.14em] text-primary">A. VERMA</p>
            <p className="text-[8px] font-medium tracking-[0.18em] text-muted-foreground">PROPRIETOR</p>
          </div>
        </div>
      </div>
    </header>
  );
}

// =============================
// Section index — numbered navigation, 01–09
// =============================

export type PageId =
  | 'dashboard'
  | 'plan-sales'
  | 'customers'
  | 'helpers'
  | 'placements'
  | 'expenses'
  | 'accounts'
  | 'journal'
  | 'reports'
  | 'settings';

const INDEX: { no: string; id: PageId; label: string }[] = [
  { no: '01', id: 'dashboard', label: 'DASHBOARD' },
  { no: '02', id: 'plan-sales', label: 'PLAN SALES' },
  { no: '03', id: 'customers', label: 'CUSTOMERS' },
  { no: '04', id: 'helpers', label: 'HELPERS' },
  { no: '05', id: 'placements', label: 'PLACEMENTS' },
  { no: '06', id: 'expenses', label: 'PAYMENTS' },
  { no: '07', id: 'accounts', label: 'ACCOUNTING' },
  { no: '08', id: 'reports', label: 'REPORTS' },
  { no: '09', id: 'settings', label: 'SETTINGS' },
];

export const PAGE_INDEX = INDEX;

export function folioNo(page: PageId): string {
  return INDEX.find((i) => i.id === page)?.no ?? '01';
}

function fyLabel(): string {
  const now = new Date();
  const y = now.getFullYear();
  const start = now.getMonth() >= 3 ? y : y - 1; // Indian FY starts April
  return `FY ${start}–${String(start + 1).slice(2)}`;
}

export function IndexNav({
  page,
  onNavigate,
}: {
  page: PageId;
  onNavigate: (p: PageId) => void;
}) {
  return (
    <nav
      aria-label="Section index"
      className="rule-double-b flex items-stretch border-t border-[#1f3a2b]/15"
    >
      <ol className="thin-scroll flex items-stretch overflow-x-auto">
        {INDEX.map((item) => {
          const active = page === item.id || (item.id === 'accounts' && page === 'journal');
          return (
            <li key={item.id} className="flex">
              <button
                onClick={() => onNavigate(item.id)}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'flex flex-col justify-center gap-0.5 px-3.5 py-2 transition-colors sm:px-5 sm:py-2.5',
                  'border-l border-[#1f3a2b]/10 first:border-l-0',
                  active
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-[#1f3a2b]/5 hover:text-primary'
                )}
              >
                <span className={cn('font-mono text-[8px] tracking-[0.08em]', active ? 'opacity-60' : 'opacity-70')}>
                  {item.no}
                </span>
                <span className="whitespace-nowrap text-[10px] font-semibold tracking-[0.12em] sm:text-[10.5px]">
                  {item.label}
                </span>
              </button>
            </li>
          );
        })}
      </ol>
      <div className="ml-auto hidden items-center gap-4 pr-1 lg:flex">
        <span suppressHydrationWarning className="whitespace-nowrap text-[9px] font-medium tracking-[0.15em] text-muted-foreground">
          {fyLabel()} · GST 18%
        </span>
        <button
          onClick={() => onNavigate('plan-sales')}
          className="bg-primary px-4 py-2 text-[10px] font-semibold tracking-[0.14em] text-primary-foreground shadow-[inset_0_1px_0_rgba(245,239,225,0.16)] transition-opacity hover:opacity-90"
        >
          +&nbsp;NEW ENTRY
        </button>
      </div>
    </nav>
  );
}

// =============================
// Folio — closing rule footer
// =============================

export function Folio({ page, warning }: { page: PageId; warning?: string }) {
  const entry = INDEX.find((i) => i.id === page) ?? INDEX[0];
  return (
    <footer className="mt-auto border-t border-[#1f3a2b]/40 px-4 py-2.5 sm:px-6 lg:px-10">
      <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-x-6 gap-y-1">
        <p className="text-[9px] font-semibold tracking-[0.14em] text-muted-foreground/80">
          BOOKS IN DOUBLE ENTRY · EVERY FIGURE INR · MYBUDDYMAID
        </p>
        <p className="flex items-center gap-4 text-[9px] font-semibold tracking-[0.14em] text-muted-foreground/80">
          {warning && <span className="text-[#8f6511]">{warning}</span>}
          <span>
            FOLIO {entry.no} — {entry.label}
          </span>
        </p>
      </div>
    </footer>
  );
}

// =============================
// Accounting sub-index (Chart of Accounts ⇄ Journal)
// =============================

export function AccountingTabs({
  active,
  onNavigate,
}: {
  active: 'accounts' | 'journal';
  onNavigate: (p: PageId) => void;
}) {
  const tabs: { id: 'accounts' | 'journal'; label: string }[] = [
    { id: 'accounts', label: 'CHART OF ACCOUNTS' },
    { id: 'journal', label: 'JOURNAL ENTRIES' },
  ];
  return (
    <div className="flex items-center gap-5" role="tablist" aria-label="Accounting sections">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          aria-selected={active === t.id}
          onClick={() => onNavigate(t.id)}
          className={cn(
            'border-b-2 pb-1 text-[10px] font-bold tracking-[0.15em] transition-colors',
            active === t.id
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-primary'
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

// =============================
// Ledger chart — hand-ruled revenue v expenses
// =============================

export interface MonthPoint {
  key: string;
  label: string;
  revenue: number;
  expenses: number;
}

const INK = '#1f3a2b';
const AMBER = '#b4822a';
const AMBER_DEEP = '#8f6511';
const PAPER = '#f5efe1';
const MUTED = '#6e6b5c';

function niceCeil(v: number): number {
  if (v <= 0) return 75_000;
  const step = v > 500_000 ? 100_000 : v > 250_000 ? 50_000 : v > 100_000 ? 25_000 : 15_000;
  return Math.ceil(v / step) * step;
}

export function LedgerChart({ months, className }: { months: MonthPoint[]; className?: string }) {
  if (!months.length) return null;

  const W = 916;
  const plotL = 34;
  const plotR = 910;
  const plotT = 18;
  const plotB = 196;
  const step = months.length > 1 ? (plotR - plotL) / (months.length - 1) : 0;
  const x = (i: number) => plotL + i * step;
  const maxV = niceCeil(Math.max(...months.map((m) => Math.max(m.revenue, m.expenses)), 1));
  const y = (v: number) => plotB - (v / maxV) * (plotB - plotT);

  const revPts = months.map((m, i) => ({ x: x(i), y: y(m.revenue), v: m.revenue }));
  const expPts = months.map((m, i) => ({ x: x(i), y: y(m.expenses), v: m.expenses }));

  // breakeven — first crossing where revenue overtakes expenses
  let crossX: number | null = null;
  let crossY = 0;
  let crossLabel = '';
  for (let i = 1; i < months.length; i++) {
    const prev = months[i - 1].revenue - months[i - 1].expenses;
    const cur = months[i].revenue - months[i].expenses;
    if (prev < 0 && cur >= 0) {
      const t = prev === cur ? 0 : -prev / (cur - prev);
      crossX = x(i - 1) + t * step;
      const e0 = months[i - 1].expenses;
      const e1 = months[i].expenses;
      crossY = y(e0 + t * (e1 - e0));
      crossLabel = months[i].label.toUpperCase();
      break;
    }
  }

  // fills between the two lines, split at the crossing
  const toPts = (pts: { x: number; y: number }[]) => pts.map((p) => `${p.x},${p.y}`).join(' ');
  const fills: { points: string; color: string }[] = [];
  if (crossX != null) {
    const leftRev = revPts.filter((p) => p.x <= crossX!);
    const leftExp = expPts.filter((p) => p.x <= crossX!);
    const rightRev = revPts.filter((p) => p.x > crossX!);
    const rightExp = expPts.filter((p) => p.x > crossX!);
    fills.push({
      points: `${toPts(leftRev)} ${crossX},${crossY} ${[...leftExp].reverse().map((p) => `${p.x},${p.y}`).join(' ')}`,
      color: 'rgba(180,130,42,.10)',
    });
    fills.push({
      points: `${crossX},${crossY} ${toPts(rightRev)} ${[...rightExp].reverse().map((p) => `${p.x},${p.y}`).join(' ')} ${crossX},${crossY}`,
      color: 'rgba(76,120,96,.14)',
    });
  } else if (months.length) {
    const net = months[months.length - 1].revenue - months[months.length - 1].expenses;
    fills.push({
      points: `${toPts(revPts)} ${[...expPts].reverse().map((p) => `${p.x},${p.y}`).join(' ')}`,
      color: net >= 0 ? 'rgba(76,120,96,.14)' : 'rgba(180,130,42,.10)',
    });
  }

  const gridLevels = [0, 1, 2, 3, 4, 5].map((i) => (maxV / 5) * i);
  const lastRev = revPts[revPts.length - 1];
  const lastExp = expPts[expPts.length - 1];
  const fmtK = (v: number) => (v >= 100_000 ? `${Math.round(v / 100_000)}L` : `${Math.round(v / 1000)}`);
  const lastMonth = months[months.length - 1];
  const lastNet = lastMonth ? lastMonth.revenue - lastMonth.expenses : 0;
  const marginNote =
    lastNet > 0
      ? `margin opens — +₹${Math.round(lastNet / 1000)}K net in ${lastMonth.label}`
      : null;

  return (
    <div className={cn('thin-scroll overflow-x-auto', className)}>
      <svg
        viewBox={`0 0 ${W} 232`}
        role="img"
        aria-label={`Revenue versus expenses, ${months[0].label} to ${months[months.length - 1].label}`}
        className="block h-auto w-full min-w-[560px]"
      >
        <title>Revenue versus expenses — last six months</title>
        {/* dotted gridlines */}
        <g stroke="rgba(31,58,43,.20)" strokeWidth="1" strokeDasharray="1 4" strokeLinecap="round">
          {gridLevels.map((v) => (
            <line key={v} x1={plotL} y1={y(v)} x2={W} y2={y(v)} />
          ))}
        </g>
        <line x1="0" y1={plotB} x2={W} y2={plotB} stroke="rgba(31,58,43,.45)" strokeWidth="1" />
        {/* y labels */}
        <g fontFamily="var(--font-plex-mono), monospace" fontSize="9.5" fill="rgba(31,58,43,.72)" textAnchor="end">
          {gridLevels.map((v) => (
            <text key={v} x={plotL - 8} y={y(v) + 3}>
              {fmtK(v)}
            </text>
          ))}
        </g>
        {/* month labels */}
        <g fontSize="9.5" letterSpacing="1.5" fill="rgba(110,107,92,.95)" textAnchor="middle" fontWeight="600">
          {months.map((m, i) => (
            <text key={m.key} x={i === months.length - 1 ? plotR - 4 : x(i)} y={216} textAnchor={i === months.length - 1 ? 'end' : 'middle'}>
              {m.label.toUpperCase()}
            </text>
          ))}
        </g>
        {/* area fills */}
        {fills.map((f, i) => (
          <polygon key={i} points={f.points} fill={f.color} />
        ))}
        {/* breakeven marker */}
        {crossX != null && (
          <g>
            <line x1={crossX} y1={plotT} x2={crossX} y2={plotB} stroke="rgba(180,130,42,.55)" strokeWidth="1" strokeDasharray="1 3" />
            <text
              x={crossX}
              y={11}
              textAnchor="middle"
              fontSize="8"
              letterSpacing="1.4"
              fill={AMBER_DEEP}
              fontWeight="700"
              stroke="rgba(245,239,225,.85)"
              strokeWidth="3"
              paintOrder="stroke"
            >
              BREAKEVEN · {crossLabel}
            </text>
          </g>
        )}
        {/* expenses — dashed amber */}
        <path
          d={`M${expPts.map((p) => `${p.x},${p.y}`).join(' L')}`}
          fill="none"
          stroke={AMBER}
          strokeWidth="2.2"
          strokeDasharray="6 5"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        {/* revenue — solid ink */}
        <path
          d={`M${revPts.map((p) => `${p.x},${p.y}`).join(' L')}`}
          fill="none"
          stroke={INK}
          strokeWidth="2.6"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        {/* point markers with native tooltips */}
        <g>
          {expPts.map((p, i) => (
            <circle key={`e${i}`} cx={p.x} cy={p.y} r="3" fill={PAPER} stroke={AMBER} strokeWidth="1.8">
              <title>{`${months[i].label} expenses ₹${months[i].expenses.toLocaleString('en-IN')}`}</title>
            </circle>
          ))}
          {revPts.map((p, i) => (
            <circle key={`r${i}`} cx={p.x} cy={p.y} r={i === revPts.length - 1 ? 3.4 : 3} fill={PAPER} stroke={INK} strokeWidth="1.8">
              <title>{`${months[i].label} revenue ₹${months[i].revenue.toLocaleString('en-IN')}`}</title>
            </circle>
          ))}
        </g>
        {/* endpoint labels */}
        <text x={plotR - 6} y={lastRev.y - 9} textAnchor="end" fontFamily="var(--font-plex-mono), monospace" fontSize="11" fontWeight="600" fill={INK}>
          ₹{fmtK(lastRev.v)}K
        </text>
        <text x={plotR - 6} y={lastExp.y + 16} textAnchor="end" fontFamily="var(--font-plex-mono), monospace" fontSize="11" fontWeight="600" fill={AMBER_DEEP}>
          ₹{fmtK(lastExp.v)}K
        </text>
        {/* margin annotation — right-anchored so it can never clip */}
        {marginNote && (
          <text
            x={plotR - 14}
            y={plotB - 12}
            textAnchor="end"
            fontFamily="var(--font-fraunces), serif"
            fontStyle="italic"
            fontSize="11.5"
            fill="rgba(31,58,43,.8)"
            stroke="rgba(245,239,225,.6)"
            strokeWidth="3"
            paintOrder="stroke"
          >
            {marginNote}
          </text>
        )}
      </svg>
    </div>
  );
}
