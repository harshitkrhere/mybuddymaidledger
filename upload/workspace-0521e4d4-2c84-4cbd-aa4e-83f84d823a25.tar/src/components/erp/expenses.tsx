'use client';

import { useEffect, useMemo, useState } from 'react';
import { Plus, Trash2, Receipt, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { fmtMoney, fmtDate, LoadingBlock, ErrorNote } from './shared';

interface ExpenseRow {
  id: string;
  date: string;
  description: string;
  amount: number;
  category: string;
  paymentMode: string;
  vendor: string | null;
}

const PAYMENT_MODES = [
  { value: 'UPI', label: 'UPI' },
  { value: 'BANK', label: 'Bank transfer' },
  { value: 'CARD', label: 'Credit/debit card' },
  { value: 'CASH', label: 'Cash' },
];

export function Expenses() {
  const { toast } = useToast();
  const [expenses, setExpenses] = useState<ExpenseRow[] | null>(null);
  const [categories, setCategories] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [query, setQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    description: '',
    amount: '',
    category: 'Marketing',
    paymentMode: 'UPI',
    vendor: '',
  });

  const load = async () => {
    try {
      setError('');
      const res = await fetch('/api/expenses?limit=200');
      if (!res.ok) throw new Error();
      const json = await res.json();
      setExpenses(json.expenses);
      setCategories(json.categories ?? []);
    } catch {
      setError('Could not load expenses. Please refresh.');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    if (!expenses) return [];
    return expenses.filter((e) => {
      if (categoryFilter !== 'ALL' && e.category !== categoryFilter) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          e.description.toLowerCase().includes(q) ||
          (e.vendor || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [expenses, categoryFilter, query]);

  const total = useMemo(
    () => filtered.reduce((s, e) => s + e.amount, 0),
    [filtered]
  );

  const submit = async () => {
    const amount = parseFloat(form.amount);
    if (!form.date || !form.description.trim() || !amount || amount <= 0) {
      toast({ title: 'Date, description and a positive amount are required.', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, amount }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to record expense');
      toast({
        title: 'Expense recorded',
        description: 'Journal entry auto-posted (expense debit, payment account credit).',
      });
      setDialogOpen(false);
      setForm({ ...form, description: '', amount: '', vendor: '' });
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : 'Failed to record expense', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const remove = async (expense: ExpenseRow) => {
    try {
      const res = await fetch(`/api/expenses?id=${expense.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      toast({ title: 'Expense deleted' });
      await load();
    } catch {
      toast({ title: 'Failed to delete expense', variant: 'destructive' });
    }
  };

  if (error) return <ErrorNote message={error} />;
  if (!expenses) return <LoadingBlock label="Loading expenses…" />;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1 sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search description or vendor…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="sm:w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All categories</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="shrink-0">
          <Plus className="mr-2 h-4 w-4" /> Record Expense
        </Button>
      </div>

      <Card className="py-0">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="rule-double-b text-left text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
                  <th className="px-6 py-3 font-bold">Date</th>
                  <th className="px-4 py-3 font-bold">Description</th>
                  <th className="hidden px-4 py-3 font-bold sm:table-cell">Vendor</th>
                  <th className="px-4 py-3 font-bold">Category</th>
                  <th className="hidden px-4 py-3 font-bold md:table-cell">Paid via</th>
                  <th className="px-4 py-3 text-right font-bold">Amount</th>
                  <th className="px-6 py-3" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((e) => (
                  <tr key={e.id} className="border-b last:border-0 transition-colors hover:bg-muted/40">
                    <td className="whitespace-nowrap px-6 py-3 text-muted-foreground">{fmtDate(e.date)}</td>
                    <td className="max-w-64 truncate px-4 py-3 font-medium">{e.description}</td>
                    <td className="hidden px-4 py-3 text-muted-foreground sm:table-cell">{e.vendor || '—'}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center whitespace-nowrap border border-[#b4822a]/60 bg-[#b4822a]/10 px-1.5 py-px text-[10px] font-semibold uppercase leading-4 tracking-[0.1em] text-[#8f6511]">
                        {e.category}
                      </span>
                    </td>
                    <td className="hidden px-4 py-3 text-muted-foreground md:table-cell">
                      {PAYMENT_MODES.find((p) => p.value === e.paymentMode)?.label || e.paymentMode}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold tabular-nums text-[#8f6511]">
                      −{fmtMoney(e.amount)}
                    </td>
                    <td className="px-6 py-3 text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-rose-600"
                        onClick={() => remove(e)}
                        aria-label="Delete expense"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-muted-foreground">
                      <Receipt className="mx-auto mb-2 h-8 w-8" />
                      <p className="text-sm font-medium">No expenses found</p>
                    </td>
                  </tr>
                )}
              </tbody>
              {filtered.length > 0 && (
                <tfoot>
                  <tr className="border-t bg-muted/30 font-semibold">
                    <td className="px-6 py-3" colSpan={5}>
                      Total ({filtered.length} expenses)
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">−{fmtMoney(total)}</td>
                    <td />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </CardContent>
      </Card>

      {/* record expense dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Record Expense</DialogTitle>
            <DialogDescription>
              The matching journal entry is posted automatically.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="exp-date">Date</Label>
                <Input
                  id="exp-date"
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="exp-amount">Amount</Label>
                <Input
                  id="exp-amount"
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })}
                  className="text-right tabular-nums"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="exp-desc">Description</Label>
              <Input
                id="exp-desc"
                placeholder="e.g. LinkedIn ads campaign"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Paid via</Label>
                <Select value={form.paymentMode} onValueChange={(v) => setForm({ ...form, paymentMode: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAYMENT_MODES.map((p) => (
                      <SelectItem key={p.value} value={p.value}>
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="exp-vendor">Vendor (optional)</Label>
              <Input
                id="exp-vendor"
                placeholder="e.g. Google Ads"
                value={form.vendor}
                onChange={(e) => setForm({ ...form, vendor: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? 'Saving…' : 'Save Expense'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
