'use client';

import { useEffect, useMemo, useState } from 'react';
import { Plus, Users, Phone, Mail, MapPin, Trash2, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { fmtMoney, fmtDate, PlanBadge, CustomerStatusBadge, LoadingBlock, ErrorNote } from './shared';
import { cn } from '@/lib/utils';

interface CustomerRow {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  city: string;
  locality: string | null;
  notes: string | null;
  planType: string | null;
  planFee: number | null;
  planPurchaseDate: string | null;
  planExpiryDate: string | null;
  placementsUsed: number;
  maxPlacements: number;
  status: string;
  hasActivePlacement: boolean;
  totalPaid: number;
  daysLeft: number | null;
}

const CITIES = ['Delhi', 'Gurgaon', 'Noida', 'Greater Noida', 'Mumbai', 'Pune', 'Bangalore', 'Mangalore'];

export function Customers() {
  const { toast } = useToast();
  const [customers, setCustomers] = useState<CustomerRow[] | null>(null);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    city: 'Delhi',
    locality: '',
    notes: '',
  });

  const load = async () => {
    try {
      setError('');
      const res = await fetch('/api/customers');
      if (!res.ok) throw new Error();
      const json = await res.json();
      setCustomers(json.customers);
    } catch {
      setError('Could not load customers. Please refresh.');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    if (!customers) return [];
    return customers.filter((c) => {
      if (statusFilter !== 'ALL' && c.status !== statusFilter) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          c.name.toLowerCase().includes(q) ||
          c.city.toLowerCase().includes(q) ||
          (c.locality || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [customers, query, statusFilter]);

  const submit = async () => {
    if (!form.name.trim() || !form.city) {
      toast({ title: 'Name and city are required.', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to add customer');
      toast({ title: `Customer "${form.name}" added`, description: 'Record a plan sale to activate coverage.' });
      setDialogOpen(false);
      setForm({ name: '', phone: '', email: '', city: 'Delhi', locality: '', notes: '' });
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : 'Failed to add customer', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  const remove = async (c: CustomerRow) => {
    try {
      const res = await fetch(`/api/customers?id=${c.id}`, { method: 'DELETE' });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to delete');
      toast({ title: `Customer "${c.name}" deleted` });
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : 'Failed to delete customer', variant: 'destructive' });
    }
  };

  if (error) return <ErrorNote message={error} />;
  if (!customers) return <LoadingBlock label="Loading customers…" />;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            placeholder="Search name, city or locality…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 sm:max-w-xs"
          />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="sm:w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All statuses</SelectItem>
              <SelectItem value="ACTIVE">Active</SelectItem>
              <SelectItem value="EXPIRED">Expired</SelectItem>
              <SelectItem value="REFUNDED">Refunded</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="shrink-0">
          <Plus className="mr-2 h-4 w-4" /> Add Customer
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {filtered.map((c) => {
          const coverageLeft = c.maxPlacements - c.placementsUsed;
          const expirySoon = c.daysLeft != null && c.daysLeft < 30 && c.daysLeft > 0;
          return (
            <div
              key={c.id}
              className={cn(
                'rounded-xl border bg-card p-5 transition-shadow hover:shadow-md',
                c.status === 'EXPIRED' && 'opacity-70'
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center bg-primary font-serif text-sm font-semibold text-primary-foreground">
                  {c.name
                    .split(' ')
                    .map((w) => w[0])
                    .slice(0, 2)
                    .join('')
                    .toUpperCase()}
                </div>
                <div className="flex items-center gap-1.5">
                  <CustomerStatusBadge status={c.status} />
                  {c.planType && <PlanBadge plan={c.planType} />}
                </div>
              </div>

              <p className="mt-3 font-semibold leading-tight">{c.name}</p>
              <p className="text-sm text-muted-foreground">
                {c.locality ? `${c.locality}, ` : ''}
                {c.city}
              </p>

              <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                {c.phone && (
                  <p className="flex items-center gap-2">
                    <Phone className="h-3.5 w-3.5 shrink-0" /> {c.phone}
                  </p>
                )}
                {c.email && (
                  <p className="flex items-center gap-2 truncate">
                    <Mail className="h-3.5 w-3.5 shrink-0" /> {c.email}
                  </p>
                )}
              </div>

              {c.planType ? (
                <div className="mt-3 space-y-2 border-t pt-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Coverage</span>
                    <span className="font-medium tabular-nums">
                      {c.placementsUsed}/{c.maxPlacements} placements
                    </span>
                  </div>
                  <div className="h-1 overflow-hidden bg-[#1f3a2b]/10">
                    <div
                      className={cn(
                        'h-full',
                        coverageLeft <= 0 ? 'bg-[#8f3b2e]' : coverageLeft <= 1 ? 'bg-[#b4822a]' : 'bg-primary'
                      )}
                      style={{ width: `${Math.min(100, (c.placementsUsed / Math.max(1, c.maxPlacements)) * 100)}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {c.planExpiryDate ? `Expires ${fmtDate(c.planExpiryDate)}` : ''}
                    </span>
                    <span
                      className={cn(
                        'font-medium',
                        expirySoon ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground'
                      )}
                    >
                      {c.daysLeft != null && c.daysLeft > 0
                        ? `${c.daysLeft} days left`
                        : c.daysLeft != null && c.daysLeft <= 0
                          ? 'Expired'
                          : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 border-t pt-2 text-xs">
                    <span
                      className={cn(
                        'flex items-center gap-1',
                        c.hasActivePlacement ? 'text-primary' : 'text-muted-foreground'
                      )}
                    >
                      <ShieldCheck className="h-3.5 w-3.5" />
                      {c.hasActivePlacement ? 'Helper placed' : 'No active placement'}
                    </span>
                    <span className="ml-auto text-muted-foreground">
                      Paid {fmtMoney(c.totalPaid, { compact: true })}
                    </span>
                  </div>
                </div>
              ) : (
                <p className="mt-3 rounded-lg bg-muted/50 p-2.5 text-xs text-muted-foreground">
                  No plan yet — record a plan sale to activate coverage.
                </p>
              )}

              {c.notes && <p className="mt-2 rounded-lg bg-muted/50 p-2.5 text-xs text-muted-foreground">{c.notes}</p>}

              {!c.planType && !c.hasActivePlacement && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="mt-2 h-7 w-7 text-muted-foreground hover:text-[#8f3b2e]"
                  onClick={() => remove(c)}
                  aria-label="Delete customer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="col-span-full flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed p-10 text-center">
            <Users className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-medium">No customers found</p>
            <p className="text-xs text-muted-foreground">Try clearing the search or filters.</p>
          </div>
        )}
      </div>

      {/* add customer dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Customer</DialogTitle>
            <DialogDescription>Create a household customer record.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="cust-name">Name *</Label>
                <Input
                  id="cust-name"
                  placeholder="Rohit Kapoor"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cust-phone">Phone</Label>
                <Input
                  id="cust-phone"
                  placeholder="+91 98xxxxxxx"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>City *</Label>
                <Select value={form.city} onValueChange={(v) => setForm({ ...form, city: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CITIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cust-locality">Locality</Label>
                <Input
                  id="cust-locality"
                  placeholder="DLF Phase 3"
                  value={form.locality}
                  onChange={(e) => setForm({ ...form, locality: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cust-email">Email</Label>
              <Input
                id="cust-email"
                type="email"
                placeholder="rohit@gmail.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cust-notes">Notes</Label>
              <Textarea
                id="cust-notes"
                placeholder="Requirements, preferences…"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? 'Adding…' : 'Add Customer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
